package com.kh.reservation.controller;

public class RoomInfoSendController {

}
